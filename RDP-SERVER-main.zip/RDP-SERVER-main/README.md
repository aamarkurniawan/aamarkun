# How to Create a Free Windows 10 RDP using GitHub | Getscreen Method | 30 min timelimit bypassed


[![Typing SVG](https://readme-typing-svg.herokuapp.com?color=16D400&size=25&width=770&lines=Free+RDP+2023)](https://git.io/typing-svg)
- FORK AGAR BERHASIL


Hai, penggemar teknologi! Selamat datang di panduan langkah demi langkah dalam menyiapkan RDP Windows 10 gratis Anda sendiri menggunakan kombinasi kuat GitHub dan metode Getscreen. 🚀

## 

Mari kita mulai dengan memecah prosesnya menjadi bagian-bagian yang sederhana dan mudah dicerna. Jangan khawatir jika Anda baru mengenal hal ini – kami akan memandu Anda melaluinya. Jika Anda belum memiliki akun GitHub, jangan khawatir!

## Getscreen Account Setup

Baiklah, mari kita ambil itu [Getscreen](https://getscreen.me/en/registration) akun bergulir. Membuat akun di sana sangatlah mudah, dan saya akan menunjukkan caranya – hanya membutuhkan waktu 1 detik! Cukup salin email Getscreen Anda ke papan teks – kami berjanji akan semudah itu. ⚡

Baiklah, pakar teknologi, saatnya menyatukan semuanya. Anda memiliki akun GitHub, akun Getscreen baru yang keren, dan alur kerja GitHub yang tepercaya. Siap untuk terjun? Ayo berguling!

### Tutorial

1. Buka GitHub, buat repositori publik baru, dan klik tombol "Unggah file". 
2. Ingat file alur kerja yang Anda unduh? Seret dan lepas file-file itu seperti pembuat kode profesional! 
3. Jika Anda menggunakan ponsel, jangan stres – saya siap membantu Anda.

### Adding Workflow Files

1. Unggah file readme.md terlebih dahulu. 2. Buat file baru, beri nama ".github/workflows/test", lakukan perubahan tersebut. 3. Tambahkan dua file alur kerja – mudah sekali!

### SETUP GETSCREEN MAIL TO WORKFLOWS (importaint part)

1. Klik salah satu alur kerja dan temukan "EMAIL_SECRET=Your Get Screen Mail" 
2. Ganti email yang Anda salin di sini, misal: "EMAIL_SECRET=example@gmail.com" 
3. Lakukan hal yang sama seperti alur kerja lainnya. Jika Anda tidak melakukannya dengan benar, Anda tidak akan mendapatkan rdp.

### Running the Workflow

Woo hoo! Inilah bagian yang menyenangkan: 

1. Klik pada tab "Actions". 
2. Pilih salah satu alur kerja tersebut. 
3. Tekan "Jalankan alur kerja". 
4. Jika Anda tidak melihat lari Anda, segarkan saja sebentar. 
5. Klik pada alur kerja yang dijalankan, tekan "Bangun sekarang", dan kemudian... saatnya menunggu!

### Getscreen and Connect

Setelah alur kerja selesai: 1. Periksa Getscreen – RDP Anda akan menyeringai dengan titik hijau! 2. Hijau artinya pergi ya? Klik "Hubungkan" dan sapa teman RDP Anda. 3. Runneradmin, bersiaplah untuk bertemu sahabat barumu!

### Speed Test and Conclusion

Mari kita selesaikan dengan tes kecepatan cepat – lagipula, Anda berhak mendapatkan pengalaman RDP secepat kilat! Itu dia, RDP Windows 10 Anda sendiri, sudah siap dan siap beraksi.

## Final Thoughts

Saat kita menyelesaikannya, berikut tipnya – jika proses pertama tidak menghasilkan RDP, jangan stres. Cobalah lagi, dan ingat, moderasi adalah kuncinya. Gunakan cara ini dengan bijak agar tetap berjalan! Terima kasih telah bergabung dengan kami dalam perjalanan teknologi ini. Ingat, petualangan teknologi bisa menyenangkan dan mudah. Berikan bintang ⭐️ jika Anda merasa panduan ini bermanfaat, tekan tombol "Ikuti", dan kami akan menemui Anda di tutorial berikutnya. Tetap paham teknologi, tetap mengagumkan! 🥳🔥


# 💻 Tech Stack:
![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=plastic&logo=javascript&logoColor=%23F7DF1E) ![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=plastic&logo=html5&logoColor=white) ![Dart](https://img.shields.io/badge/dart-%230175C2.svg?style=plastic&logo=dart&logoColor=white) ![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=plastic&logo=css3&logoColor=white) ![PHP](https://img.shields.io/badge/php-%23777BB4.svg?style=plastic&logo=php&logoColor=white) ![Python](https://img.shields.io/badge/python-3670A0?style=plastic&logo=python&logoColor=ffdd54) ![TypeScript](https://img.shields.io/badge/typescript-%23007ACC.svg?style=plastic&logo=typescript&logoColor=white) ![Windows Terminal](https://img.shields.io/badge/Windows%20Terminal-%234D4D4D.svg?style=plastic&logo=windows-terminal&logoColor=white) ![PowerShell](https://img.shields.io/badge/PowerShell-%235391FE.svg?style=plastic&logo=powershell&logoColor=white) ![Perl](https://img.shields.io/badge/perl-%2339457E.svg?style=plastic&logo=perl&logoColor=white) ![Cloudflare](https://img.shields.io/badge/Cloudflare-F38020?style=plastic&logo=Cloudflare&logoColor=white) ![AWS](https://img.shields.io/badge/AWS-%23FF9900.svg?style=plastic&logo=amazon-aws&logoColor=white) ![Azure](https://img.shields.io/badge/azure-%230072C6.svg?style=plastic&logo=microsoftazure&logoColor=white) ![Firebase](https://img.shields.io/badge/firebase-%23039BE5.svg?style=plastic&logo=firebase) ![GithubPages](https://img.shields.io/badge/github%20pages-121013?style=plastic&logo=github&logoColor=white) ![DigitalOcean](https://img.shields.io/badge/DigitalOcean-%230167ff.svg?style=plastic&logo=digitalOcean&logoColor=white) ![Google Cloud](https://img.shields.io/badge/GoogleCloud-%234285F4.svg?style=plastic&logo=google-cloud&logoColor=white) ![Heroku](https://img.shields.io/badge/heroku-%23430098.svg?style=plastic&logo=heroku&logoColor=white) ![Linode](https://img.shields.io/badge/linode-00A95C?style=plastic&logo=linode&logoColor=white) ![Netlify](https://img.shields.io/badge/netlify-%23000000.svg?style=plastic&logo=netlify&logoColor=#00C7B7) ![OVH](https://img.shields.io/badge/ovh-%23123F6D.svg?style=plastic&logo=ovh&logoColor=#123F6D) ![Vercel](https://img.shields.io/badge/vercel-%23000000.svg?style=plastic&logo=vercel&logoColor=white) ![Anaconda](https://img.shields.io/badge/Anaconda-%2344A833.svg?style=plastic&logo=anaconda&logoColor=white) ![.Net](https://img.shields.io/badge/.NET-5C2D91?style=plastic&logo=.net&logoColor=white) ![Bootstrap](https://img.shields.io/badge/bootstrap-%238511FA.svg?style=plastic&logo=bootstrap&logoColor=white) ![Chakra](https://img.shields.io/badge/chakra-%234ED1C5.svg?style=plastic&logo=chakraui&logoColor=white) ![Chart.js](https://img.shields.io/badge/chart.js-F5788D.svg?style=plastic&logo=chart.js&logoColor=white) ![Code-Igniter](https://img.shields.io/badge/CodeIgniter-%23EF4223.svg?style=plastic&logo=codeIgniter&logoColor=white) ![DaisyUI](https://img.shields.io/badge/daisyui-5A0EF8?style=plastic&logo=daisyui&logoColor=white) ![Django](https://img.shields.io/badge/django-%23092E20.svg?style=plastic&logo=django&logoColor=white) ![Express.js](https://img.shields.io/badge/express.js-%23404d59.svg?style=plastic&logo=express&logoColor=%2361DAFB) ![Flutter](https://img.shields.io/badge/Flutter-%2302569B.svg?style=plastic&logo=Flutter&logoColor=white) ![Gatsby](https://img.shields.io/badge/Gatsby-%23663399.svg?style=plastic&logo=gatsby&logoColor=white) ![Hugo](https://img.shields.io/badge/Hugo-black.svg?style=plastic&logo=Hugo) ![Laravel](https://img.shields.io/badge/laravel-%23FF2D20.svg?style=plastic&logo=laravel&logoColor=white) ![jQuery](https://img.shields.io/badge/jquery-%230769AD.svg?style=plastic&logo=jquery&logoColor=white) ![JWT](https://img.shields.io/badge/JWT-black?style=plastic&logo=JSON%20web%20tokens) ![Metero JS](https://img.shields.io/badge/meteorjs-%23d74c4c.svg?style=plastic&logo=meteor&logoColor=white) ![MUI](https://img.shields.io/badge/MUI-%230081CB.svg?style=plastic&logo=mui&logoColor=white) ![NPM](https://img.shields.io/badge/NPM-%23CB3837.svg?style=plastic&logo=npm&logoColor=white) ![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=plastic&logo=node.js&logoColor=white) ![Next JS](https://img.shields.io/badge/Next-black?style=plastic&logo=next.js&logoColor=white) ![Nuxt JS](https://img.shields.io/badge/Nuxt-002E3B?style=plastic&logo=nuxt.js&logoColor=#00DC82) ![Redux](https://img.shields.io/badge/redux-%23593d88.svg?style=plastic&logo=redux&logoColor=white) ![Socket.io](https://img.shields.io/badge/Socket.io-black?style=plastic&logo=socket.io&badgeColor=010101) ![Strapi](https://img.shields.io/badge/strapi-%232E7EEA.svg?style=plastic&logo=strapi&logoColor=white) ![Svelte](https://img.shields.io/badge/svelte-%23f1413d.svg?style=plastic&logo=svelte&logoColor=white) ![TailwindCSS](https://img.shields.io/badge/tailwindcss-%2338B2AC.svg?style=plastic&logo=tailwind-css&logoColor=white) ![Vue.js](https://img.shields.io/badge/vue.js-%2335495e.svg?style=plastic&logo=vuedotjs&logoColor=%234FC08D) ![Vite](https://img.shields.io/badge/vite-%23646CFF.svg?style=plastic&logo=vite&logoColor=white) ![Vuetify](https://img.shields.io/badge/Vuetify-1867C0?style=plastic&logo=vuetify&logoColor=AEDDFF) ![Web3.js](https://img.shields.io/badge/web3.js-F16822?style=plastic&logo=web3.js&logoColor=white) ![Yarn](https://img.shields.io/badge/yarn-%232C8EBB.svg?style=plastic&logo=yarn&logoColor=white) ![WordPress](https://img.shields.io/badge/WordPress-%23117AC9.svg?style=plastic&logo=WordPress&logoColor=white) ![Apache](https://img.shields.io/badge/apache-%23D42029.svg?style=plastic&logo=apache&logoColor=white) ![Nginx](https://img.shields.io/badge/nginx-%23009639.svg?style=plastic&logo=nginx&logoColor=white) ![Apache Flink](https://img.shields.io/badge/Apache%20Flink-E6526F?style=plastic&logo=Apache%20Flink&logoColor=white) ![Jenkins](https://img.shields.io/badge/jenkins-%232C5263.svg?style=plastic&logo=jenkins&logoColor=white) ![MongoDB](https://img.shields.io/badge/MongoDB-%234ea94b.svg?style=plastic&logo=mongodb&logoColor=white) ![MySQL](https://img.shields.io/badge/mysql-%2300000f.svg?style=plastic&logo=mysql&logoColor=white) ![MicrosoftSQLServer](https://img.shields.io/badge/Microsoft%20SQL%20Server-CC2927?style=plastic&logo=microsoft%20sql%20server&logoColor=white) ![Canva](https://img.shields.io/badge/Canva-%2300C4CC.svg?style=plastic&logo=Canva&logoColor=white) ![Figma](https://img.shields.io/badge/figma-%23F24E1E.svg?style=plastic&logo=figma&logoColor=white) ![Blender](https://img.shields.io/badge/blender-%23F5792A.svg?style=plastic&logo=blender&logoColor=white) ![Docker](https://img.shields.io/badge/docker-%230db7ed.svg?style=plastic&logo=docker&logoColor=white) ![AZUREDEVOPS](https://img.shields.io/badge/azuredevops-0078D7.svg?style=plastic&logo=azuredevops&logoColor=white&color=%230078D7) ![CIRCLECI](https://img.shields.io/badge/CIRCLECI-02303A.svg?style=plastic&logo=CIRCLECI&logoColor=white&color=%23343434) ![Docker](https://img.shields.io/badge/docker-%230db7ed.svg?style=plastic&logo=docker&logoColor=white) ![Gradle](https://img.shields.io/badge/Gradle-02303A.svg?style=plastic&logo=Gradle&logoColor=white) ![Arduino](https://img.shields.io/badge/-Arduino-00979D?style=plastic&logo=Arduino&logoColor=white) ![Portfolio](https://img.shields.io/badge/Portfolio-%23000000.svg?style=plastic&logo=firefox&logoColor=#FF7139) ![Postman](https://img.shields.io/badge/Postman-FF6C37?style=plastic&logo=postman&logoColor=white) ![Terraform](https://img.shields.io/badge/terraform-%235835CC.svg?style=plastic&logo=terraform&logoColor=white)
# 📊 GitHub Stats:
![](https://github-readme-stats.vercel.app/api?username=kawainime&theme=dark&hide_border=false&include_all_commits=true&count_private=true)<br/>
![](https://github-readme-streak-stats.herokuapp.com/?user=kawainime&theme=dark&hide_border=false)<br/>
![](https://github-readme-stats.vercel.app/api/top-langs/?username=kawainime&theme=dark&hide_border=false&include_all_commits=true&count_private=true&layout=compact)

## 🏆 GitHub Trophies
![](https://github-profile-trophy.vercel.app/?username=kawainime&theme=radical&no-frame=false&no-bg=false&margin-w=4)

### ✍️ Random Quote
![](https://quotes-github-readme.vercel.app/api?type=horizontal&theme=tokyonight)

### 🔝 Top Contributed Repo
![](https://github-contributor-stats.vercel.app/api?username=kawainime&limit=5&theme=matrix&combine_all_yearly_contributions=true)

### 😂 Random Dev Meme
<img src='https://randommeme-five.vercel.app/' style="height: 400px;"/>

---
[![](https://visitcount.itsvg.in/api?id=kawainime&icon=0&color=9)](https://visitcount.itsvg.in)

<!-- Proudly created with GPRM ( https://gprm.itsvg.in ) -->

## DEMO PICTURE 

![7baa8501c47f46515f40a6366abb0b41-picsay](https://github.com/kawainime/RDP-SERVER/assets/147604824/7b40414f-f449-45b6-b393-f4c066960b19)
![a684404e07e12d571265235b66de985e-picsay](https://github.com/kawainime/RDP-SERVER/assets/147604824/bc132029-46bb-40a8-9cd2-d31c4c359d4c)
![80bebb3a1b285f0dfe936cf42349235e-picsay](https://github.com/kawainime/RDP-SERVER/assets/147604824/b817374c-fa3c-4e73-ac4b-d28c2196ac48)
![download (2)](https://github.com/kawainime/RDP-SERVER/assets/147604824/a463ff9f-5546-4e4f-a793-58dc3b109836)
![jammies](https://github.com/kawainime/RDP-SERVER/assets/147604824/752f7d52-6d34-40ae-bbdc-75fa6e5fb2b9)
![_d4d9986e-bb7c-4486-b738-c4a3d9a1f192](https://github.com/kawainime/RDP-SERVER/assets/147604824/a4bcea24-762c-413a-a11b-e9805583af7e)
![Screenshot_2023-11-28-21-42-57-932_com android chrome-picsay](https://github.com/kawainime/RDP-SERVER/assets/147604824/8503a6be-9cf4-47e0-b61d-9ada59b0fb89)
![Screenshot_2023-11-28-21-42-35-852_com android chrome-picsay](https://github.com/kawainime/RDP-SERVER/assets/147604824/b950861b-28c3-4179-b734-f095972c0be4)
![Screenshot_2023-11-28-21-41-07-133_com kiwibrowser browser-picsay](https://github.com/kawainime/RDP-SERVER/assets/147604824/81ed8c39-028a-4c95-94ce-59e1cea011e2)

